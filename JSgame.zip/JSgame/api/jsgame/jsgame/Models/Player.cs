﻿using System.ComponentModel.DataAnnotations;

namespace jsgame.Models
{
    public class Player
    {
        [Key]
        public string Name { get; set; }
        public int Score { get; set; }
    }
}