﻿using jsgame.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Net.Security;

namespace jsgame.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PlayerController : ControllerBase
    {
        private readonly PlayerContext _context;

        public PlayerController(PlayerContext context) {
            _context = context;
        }
        [HttpGet]
        public async Task<ActionResult> GetPlayers()
        {
            try
            {
                var players = await _context.Players.ToListAsync();
                return Ok(players);
            }
            catch
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Error retrieving data from the database");

            };
        }

        [HttpPut("{name}")]
        public async Task<IActionResult> UpdatePlayer(string name, Player updatedPlayer)
        {
            if (name != updatedPlayer.Name)
            {
                return BadRequest("Player name mismatch");
            }

            var player = await _context.Players.FirstOrDefaultAsync(p => p.Name == name);
            if (player == null)
            {
                return NotFound();
            }

            player.Score = updatedPlayer.Score;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!PlayerExists(name))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }


        private bool PlayerExists(string name)
        {
            return _context.Players.Any(e => e.Name == name);
        }
    }
}

