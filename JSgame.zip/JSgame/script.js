

const playButton = document.getElementById("playButton");

playButton.addEventListener("click", game);

function game() {
playButton.style.display = "block";    
    let gameRunning = true;
    R = true;
    O = true;

    playButton.style.display = "none";
    const canvas = document.getElementById("gameArea");
    canvas.style.display = "block";
    canvas.width = 1528;
    canvas.height = 856;
    console.log(canvas.width, canvas.height);

    var audio = new Audio('audio/Cool.unfinishedv1.mp3');

    audio.onended = function() {
        this.play();
    };
    
    audio.play();
    const ctx = canvas.getContext("2d");

    let bullets = [];

    // Class for using 
    class player {
        constructor(buttonUp, buttonRight, buttonLow, buttonLeft, fireShot, x, y, spawnX, spawnY, name) {
            this.buttonUp = buttonUp;
            this.buttonRight = buttonRight;
            this.buttonLow = buttonLow;
            this.buttonLeft = buttonLeft;
            this.fireShot = fireShot;
            this.x = x;
            this.y = y;
            this.spawnX = spawnX;
            this.spawnY = spawnY;
            this.name = name;
            this.downPressed = false;
            this.upPressed = false;
            this.leftPressed = false;
            this.rightPressed = false;
            this.firedShot = false;
            
            this.health = 100;
            this.speed = 7;
            this.radius = 30;   
            this.direction = {x: 0, y: 0}
            this.score = 0;
            // this.firedShot = false;
            this.color = "green";
        }
    }

    class Projectile {
        constructor(x, y, direction, velocity) {
            this.x = x;
            this.y = y;
            this.direction = direction;
            this.velocity = velocity;
            this.bulletRadius = 5;
            this.bulletSpeed = 25;

        }
        update() {
            this.x += this.bulletSpeed * this.direction.x;
            this.y += this.bulletSpeed * this.direction.y;
        }
        draw(ctx) {
            ctx.fillStyle = "red";

            ctx.beginPath();
            ctx.arc(this.x, this.y, this.bulletRadius, 0, Math.PI * 2);
            ctx.fill();
        }
    }

    class pointsArea {
        constructor() {
            this.x = 754;
            this.y = 428;
            this.radius = 250;
            this.color = "#011c45";
        }
        draw(ctx)  {
            ctx.fillStyle = this.color;
            ctx.beginPath();
            ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
            ctx.fill();
        }   
    }

    let Jesse = new player(87, 68, 83, 65, 69, 100, 428, 200, 428, "Jesse");
    let Rob = new player(73, 76, 75, 74, 85, 1428, 428, 1428, 428, "Rob");
    let players = [Jesse, Rob];

    
    function fireBullet(player) {
        let spawnX = player.x + player.direction.x * (player.radius + 1);
        let spawnY = player.y + player.direction.y * (player.radius + 1);

        let bullet = new Projectile(spawnX, spawnY, player.direction, player.fireShot);
        
        bullets.push(bullet);
        var audio = new Audio('audio/gunshot.mp3');
        audio.play();
    }

    function updateBullets() {
        // Add bullet to list when keypressed
        for(i = 0; i < bullets.length; i++) {
            let bullet = bullets[i];
            bullet.update();
            bullet.draw(ctx);

            // Check for collision with each player
            for(let player of players) {
                let dx = player.x - bullet.x;
                let dy = player.y - bullet.y;
                let distance = Math.sqrt(dx * dx + dy * dy);

                if(distance < player.radius + bullet.bulletRadius & player.health > 0) {
                    audio = new Audio('audio/malegrunt.mp3');
                    audio.play();
                    player.health -= 20;
                    console.log(player.health);
                    // Remove the bullet
                    bullets.splice(i, 1);
                    i--;
                    break;
                }
                }
            // Remove the bullet if it goes off screen
            if (bullet.x > canvas.width || bullet.x < 0 || bullet.y > canvas.height || bullet.y < 0) {
                bullets.splice(i, 1);
                i--;
            }
        }
    }

    function area() {
        for (let player of players) {
            // Check if the interval has not been set for this player
            if (!player.intervalSet) {
                player.intervalSet = true;
                // Store the interval ID in the player object
                player.intervalId = setInterval(() => {
                    let dx = player.x - gameArea.x;
                    let dy = player.y - gameArea.y;
                    let distance = Math.sqrt(dx * dx + dy * dy);
                    let playerInArea = distance < player.radius + gameArea.radius && player.health > 0;
                    
                    if(playerInArea) {
                        player.score++;
                        console.log(player.score);
                    }
    
                    if(player.score >= 20) {
                        playgame = false;
                        playButton.style.display = "block";
                        // Use the stored interval ID to clear the interval
                        clearInterval(player.intervalId);
                    }
                }, 1000);
            }
        }
    }
    function drawScoreboard() {
        let scoreboardText = 'Scoreboard:\n';
        players.forEach((player) => {
            scoreboardText += `${player.name}: ${player.score}\n`;
        });
    
        // Set scoreboard display properties
        ctx.font = '16px Arial';
        ctx.fillStyle = '#0095DD';
        ctx.fillText(scoreboardText, 8, 20);
    }
    
    let playersData = []; // Global variable to store players data
    
    function updatePlayerWinsByName(player) {
        console.log(player);

        if (player) {
            console.log(player);
            let playerId = player.id; 
            let Name = player.name
            console.log(playerId);
            // const player = player + 1;
            updatePlayerWins(Name, );
        } else {
            console.log(`Player with name ${Name} not found.`);
        }
    }



    function updatePlayerWins(player) {
        let name = player.name;
        // Fetch all players
        fetch('https://localhost:7235/api/Player', {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json'
            }
        })
        .then(response => response.json())
        .then(players => {
            let player1 = players.find(p => p.name == name);
            let Name = player1.name;
            let Score = player1.score + 1;
    
            let body = { Name, Score };
            // Correctly chain the fetch call with .then() to handle the response
            return fetch(`https://localhost:7235/api/Player/${player1.name}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(body)
            });
        })
        .then(response => { // This .then() now correctly chains to the fetch call above
            if (response && response.ok) {
                console.log(`Wins updated for ${name}`);
            } else {
                console.error('Failed to update wins');
            }
        })
        .catch(error => console.error('Error:', error));
    }
    
    function inputs(player) {
        if (player.downPressed) {
            player.y = player.y + player.speed;
            player.direction = { x: 0, y: 1 };
        }

        if (player.upPressed) {
            player.y = player.y - player.speed;
            player.direction = { x: 0, y: -1 };
        }

        if (player.leftPressed) {
            player.x = player.x - player.speed;
            player.direction = { x: -1, y: 0 };
        }

        if (player.rightPressed) {
            player.x = player.x + player.speed;
            player.direction = { x: 1, y: 0 };
        }
    }

    function playerDeath() {
        ctx.fillStyle = "red";
        var audio = new Audio('audio/malescream.mp3');
        audio.play();
    }

    function revivePlayer(player) {
            player.health = 100;
            player.x = player.spawnX;
            player.y = player.spawnY;
            ctx.fillStyle = "green";
            R = true;
        }

    function clearScreen() {
        ctx.fillStyle = 'black';
        ctx.fillRect(0, 0, canvas.clientWidth, canvas.height);
    }


    function gameLoop() {
        if (gameRunning == false) {
            return;
        }
        requestAnimationFrame(gameLoop);
        clearScreen();
        if (O == true) {
            drawScoreboard();
        }

        gameArea = new pointsArea();
        gameArea.draw(ctx);
    
        players.forEach(function(player) {
            area();
            if (player.score >= 20) {

                updatePlayerWins(player);
                gameRunning = false;
                return;
            }
            if (player.health > 0) {
                inputs(player);
            }
        
            ctx.beginPath();
            
            ctx.arc(player.x, player.y, player.radius, 0, Math.PI * 2);
            ctx.fillStyle = player.color;

            if (player.health <= 0) {
                playerDeath(player);
                if (R == true) {
                    setTimeout(function() {
                        revivePlayer(player);
                    }, 2000);
                }
                R = false;
            }

            ctx.fill();
        });
        updateBullets();

    }

    document.body.addEventListener('keydown', keyDown);
    document.body.addEventListener('keyup', keyUp);

    function keyDown(event) {
        players.forEach(function(player) {
            if (event.keyCode == player.buttonUp) {
                player.upPressed = true;
            }
            if (event.keyCode == player.buttonRight) {
                player.rightPressed = true;
            }
            if (event.keyCode == player.buttonLow) {
                player.downPressed = true;
            }
            if (event.keyCode == player.buttonLeft) {
                player.leftPressed = true;
            }
            if (event.keyCode == player.fireShot) {
                fireBullet(player);
                player.firedShot = true;

                console.log(`Player ${player.id} fire key pressed`);
            }
        });
    }

    function keyUp(event) {
        players.forEach(function(player) {
            if (event.keyCode == player.buttonUp) {
                player.upPressed = false;
            }
            if (event.keyCode == player.buttonRight) {
                player.rightPressed = false;
            }
            if (event.keyCode == player.buttonLow) {
                player.downPressed = false;
            }
            if (event.keyCode == player.buttonLeft) {
                player.leftPressed = false;
            }
            if (event.keyCode == player.fireShot) {
                player.firedShot = false;
            }
        });
    }

    gameLoop();
}